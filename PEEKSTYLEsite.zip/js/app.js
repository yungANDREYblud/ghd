var links = document.querySelectorAll('.tr-items');
console.log(links.length)
let too_links = document.querySelectorAll('.tooltip')





for (let i = 0; i < too_links.length; i++) {
    too_links[i].style.visibility = "hidden"
}


for (let i = 0; i < links.length; i++) {
    links[i].addEventListener('mouseover', function(){
        let too = links[i].querySelector('.tooltip')
        too.style.visibility = "visible"
        console.log(too)
    })
    // links[i].onmouseover = function() {
    //     var tooltip = document.getElementsByClassName('tooltip');
    //     console.log(links[i])
    //     var tooltip = links[i];
    //     too.style.opcity = "1";
    //     too.style.visibility = "visible";
    // }
    
    // links[i].onmouseover = function() {
    //     var tooltip = document.getElementsByClassName('tooltip');
    //     var tooltip = links[i];
    //     too.style.opcity = "0";
    //     too.style.visibility = "hidden";
    // }
}
for (let i = 0; i < links.length; i++) {
    links[i].addEventListener('mouseout', function(){
        let too = links[i].querySelector('.tooltip')
        too.style.visibility = "hidden"
    })

}

var links2 = document.querySelectorAll('.b-c');
console.log(links.length)
let to_links2 = document.querySelectorAll('.tip')


for (let i = 0; i < to_links2.length; i++) {
    to_links2[i].style.visibility = "hidden"
}

for (let i = 0; i < links2.length; i++) {
    links2[i].addEventListener('mouseover', function(){
        let to = links2[i].querySelector('.tip')
        to.style.visibility = "visible"
        console.log(to)
    })
}

for (let i = 0; i < links2.length; i++) {
    links2[i].addEventListener('mouseout', function(){
        let to = links2[i].querySelector('.tip')
        to.style.visibility = "hidden"
    })
    
}


let left = document.querySelector("#btnLeft")
let right = document.querySelector("#btnRight")
let sliders = document.querySelectorAll(".ban")

console.log(sliders.length)

let num = 0

left.addEventListener("click", function(){
    num--
    if (num < 0) {
        num = sliders.length - 1
    }
    for (let i = 0; i < sliders.length; i++){
        sliders[i].classList.remove('active')
    }
    console.log(num)
    sliders[num].classList.add('active')
})

right.addEventListener("click", function(){
    num++
    if (num > sliders.length - 1) {
        num = 0
    }
    for (let i = 0; i < sliders.length; i++){
        sliders[i].classList.remove('active')
    }
    console.log(num)
    sliders[num].classList.add('active')
})

